# Supplementary material

Revised manuscript: "Wildlife Strike Hazard in the Low-Altitude Urban Air Mobility Envelope: A Selection-Corrected Analysis of 97,162 FAA Records and an Exposure-Normalized Corridor Risk Index" (Journal of Aviation Technology and Engineering, R1).

## Contents
- `code/uam_wildlife_r1.py` – complete analysis: data cleaning, representativeness tests, post-stratification weights, adjusted logistic model, rotorcraft analysis, seasonal and trend analysis, UCRI, hold-out validation, sensitivity analyses and Figures 1–7.
- `data/atads_ops_2010_2025.csv` – annual operations for 45 airports from the FAA Air Traffic Activity Data System (ATADS).
- `results/` – outputs of the script used in the manuscript: `results.json` (all reported statistics), `ucri_corridors.csv` (Table 5), `validation_airports.csv` (Table 6, Figure 7), `weight_grid.csv` and `weight_selected.csv` (Table A1), `buffer_shrinkage.csv` (Table A2), `species_damage_probability.csv` (species damage probabilities, Equation 6), `annual_trend.csv` (Figure 5a).

## Reproduction
1. Download the NWSD public database (Public.xlsx) from https://wildlife.faa.gov.
2. `pip install pandas numpy scipy statsmodels matplotlib openpyxl`
3. `python code/uam_wildlife_r1.py --nwsd Public.xlsx --ops data/atads_ops_2010_2025.csv --out results`

The NWSD release used in the paper was downloaded in April 2026 (342,075 records, 2 January 1990 – 30 March 2026). Later releases will add records and change values slightly. Bootstrap seeds are fixed. A full run takes about 15–25 minutes; `--fast` reduces bootstrap replicates for a quick check.
